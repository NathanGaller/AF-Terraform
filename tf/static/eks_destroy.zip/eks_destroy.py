import boto3
import json
import time

def lambda_handler(event, context):
    # Retrieve the cluster name from the input event
    cluster_name = event.get('cluster_name')

    # Initialize an EKS client
    eks_client = boto3.client('eks')

    # Retrieve the list of nodegroup names
    nodegroup_names = eks_client.list_nodegroups(clusterName=cluster_name)['nodegroups']

    # Delete the nodegroups
    for nodegroup_name in nodegroup_names:
        try:
            eks_client.delete_nodegroup(
                clusterName=cluster_name,
                nodegroupName=nodegroup_name
            )
        except Exception as e:
            return {
                'statusCode': 500,
                'body': json.dumps(f'Error deleting nodegroup {nodegroup_name} from EKS cluster {cluster_name}: {e}')
            }
        
        # Wait for the nodegroup to be deleted
        while True:
            nodegroups = eks_client.list_nodegroups(clusterName=cluster_name)['nodegroups']
            if nodegroup_name not in nodegroups:
                break
            time.sleep(10)

    # Delete the EKS cluster
    try:
        eks_client.delete_cluster(name=cluster_name)
        return {
            'statusCode': 200,
            'body': json.dumps(f'EKS cluster {cluster_name} deleted.')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error deleting EKS cluster {cluster_name}: {e}')
        }